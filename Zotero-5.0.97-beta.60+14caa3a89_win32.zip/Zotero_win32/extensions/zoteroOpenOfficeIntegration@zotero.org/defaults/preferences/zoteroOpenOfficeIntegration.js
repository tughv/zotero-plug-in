pref("extensions.zoteroOpenOfficeIntegration.unopkgPaths", "{}");
pref("extensions.zoteroOpenOfficeIntegration.version", "");
pref("extensions.zoteroOpenOfficeIntegration.installed", false);
pref("extensions.zoteroOpenOfficeIntegration.skipInstallation", false);